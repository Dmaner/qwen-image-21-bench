# C1 H200 supplement — frozen before inference

Date: 2026-10-13 (Asia/Shanghai). Status: preparation; no new GPU results yet.

## Questions

1. Does protecting every DiT `img_mlp` reproduce the selective configuration in #8099, and improve quality relative to all eligible DiT Linears in FP8?
2. What quality, latency and actual memory changes follow from native, V-only FP8 and K+V FP8 prefix storage?
3. Do the reported weight-quantization configurations preserve editing intent on distinct human, object and text-bearing inputs?

## Fixed controls

One newly provisioned Runpod Secure H200 SXM, with fresh BF16 controls on this same device. Omni `3dc35694b3d458fc1461a8fe71832ac12e8c8cea`; vLLM 0.31.0; Torch 2.13.0+cu130; Triton 3.7.1; Transformers 5.14.1; Diffusers 0.40.0. Model `Qwen/Qwen-Image-2.1@d26bb61231c349cf6b7896fa83353113880e1ba3`. Same immutable official vLLM image as the original C1 campaign. Record actual GPU UUID, driver and package inventory.

Main comparison: 1024x1024, 50 steps, true CFG=1, batch/concurrency=1, eager, FA3. No offload, tiling, compilation of the model, CUDA Graph or approximate cache. Keep native prefix reuse enabled. Existing internal activation-quantization kernels are unchanged. A separate teapot/seed42/CFG4 block checks the workload settings of the #8099 prefix example; do not pool it with CFG1.

## Configurations

| Arm | Eligible DiT Linears | Text encoder | Prefix storage |
|---|---|---|---|
| bf16 | BF16 | BF16 | native BF16 (`auto`) |
| dit_fp8 | 160 FP8 | BF16 | native BF16 |
| mlp_bf16 | 64 attention Linears FP8; 96 img_mlp Linears BF16 | BF16 | native BF16 |
| te_fp8 | BF16 | 252 language Linears FP8 | native BF16 |
| joint_fp8 | 160 FP8 | 252 language Linears FP8 | native BF16 |
| prefix_fp8_v | BF16 | BF16 | K BF16, V E4M3 with FP32 scales |
| prefix_fp8 | BF16 | BF16 | K and V E4M3 with FP32 scales |

VAE, vision encoder, LM head and DiT boundary projections stay BF16. Attention compute remains BF16. The old first/last-four-block experiment is not used. For this pinned vLLM, explicit full-name glob patterns target the same img_mlp modules as #8099; actual worker inventory must confirm 64/96 before measurements.

## Inputs and measurements

Freeze input bytes, SHA256, prompts, seeds and manifest before first inference. Reuse the 24 original quality cases, add three distinct single-reference edits (person, object, text sign) at seeds42/43/44, and a two-reference edit at the same three seeds. Keep historical and newly introduced cases identifiable. The three two-reference cases also exercise a longer prefix. Score corresponding BF16/candidate outputs with identical requests.

Primary performance: teapot T2I and original bear edit for all seven arms, plus the two-reference edit for bf16/prefix_fp8_v/prefix_fp8. Each fresh engine uses 1 warmup + 1 feasibility + 10 measured requests. Report mean/sample SD and successful/failed counts; no serving throughput claim. Record per-request timings for all quality cases as diagnostic data, not n=10 benchmarks.

Peak allocated/reserved memory: independent warmup + one measured request for each primary performance cell, measured inside the worker. Prefix audit additionally measures cached tensor and scale bytes, logical bytes and unique backing-storage bytes, prefix length and attention compute dtype. Do not infer whole-model memory savings from FP8 element size.

Profiler: independent two-reference captures for native, V-only FP8 and K+V FP8; inspect dequantization and packing costs. Store raw traces privately in the local archive and publish only necessary summaries/evidence. Profiling does not replace unprofiled request timing.

## Quality gate declared before this supplement

Working numerical gate: every pair must have LPIPS(AlexNet v0.1) <=0.15, using the same full-resolution RGB method as the archived C1 scorer. This is the repository default adopted for this experiment, not a maintainer-approved Qwen-Image-2.1 acceptance threshold. Report PSNR/SSIM/LPIPS per case and category, counts passing/failing and worst cases; do not use a global mean as a pass criterion. Baseline output is a comparison reference, not semantic ground truth.

Semantic criteria: requested text remains exact when BF16 is correct; edited subject and unrequested attributes remain recognisable; requested edit is completed; no newly missing text or obvious deformation. Model-assisted checks are labelled as such. Human confirmation and maintainer acceptance remain pending until actually provided. Preserve BF16 failures too. Existing-image re-scoring is retrospective; do not relabel old evaluations as predeclared.

Record missing images, black images, non-finite values, exceptions and OOM rather than dropping them. Stop an arm if its runtime quantization/cache audit fails. Do not change the configuration or gate after seeing quality results; any change creates a separately labelled protocol version.

## Cost and delivery

One H200 at the current catalog rate of $5.29/hour; soft target 3 hours, review at 4 hours, bound workload processes to 6 hours. Save evidence locally before releasing the task-created compute. Do not modify unrelated Pods or volumes. Publish a concise experimental design, updated C1 report, reproducible commands, compact JSON/CSV data and a few representative comparisons to Dmaner/qwen-image-21-bench. Preserve A0 report and existing historical data. No Issue comments will be posted.
